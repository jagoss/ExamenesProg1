package prog1.entidades;

import java.util.ArrayList;
import java.util.List;

public class Libro {

    private long isbn;
    private String titulo;
    private List<String> autores;

    public Libro(long isbn, String titulo, ArrayList<String> autores){
        this.isbn = isbn;
        this.autores = autores;
        this.titulo = titulo;
    }

    public long getIsbn() {
        return isbn;
    }

    public void setIsbn(long isbn) {
        this.isbn = isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public List<String> getAutores() {
        return autores;
    }

    public void setAutores(List<String> autores) {
        this.autores = autores;
    }

    @Override
    public boolean equals(Object obj){
        boolean exit = false;

        if(obj != null && obj instanceof Libro && this.getIsbn() == ((Libro) obj).getIsbn()){
            exit = true;
        }
        return exit;
    }
}
