package prog1.entidades;

import java.util.ArrayList;

public final class Braille extends Libro {

    public Braille(long isbn, String titulo, ArrayList<String> autores){
        super(isbn, titulo, autores);
    }
}
