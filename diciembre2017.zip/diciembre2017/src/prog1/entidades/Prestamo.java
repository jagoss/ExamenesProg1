package prog1.entidades;

import java.time.LocalDate;

public class Prestamo {

    private String cedula;
    private LocalDate desde;
    private LocalDate hasta;
    private boolean estaDevuelto;
    private Libro libroPrestado;

    public Prestamo (String cedula, LocalDate desde, LocalDate hasta, boolean estaDevuelto, Libro libroPrestado){
        this.cedula = cedula;
        this.desde = desde;
        this.hasta = hasta;
        this.estaDevuelto = estaDevuelto;
        this.libroPrestado = libroPrestado;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public LocalDate getDesde() {
        return desde;
    }

    public void setDesde(LocalDate desde) {
        this.desde = desde;
    }

    public LocalDate getHasta() {
        return hasta;
    }

    public void setHasta(LocalDate hasta) {
        this.hasta = hasta;
    }

    public boolean isEstaDevuelto() {
        return estaDevuelto;
    }

    public void setEstaDevuelto(boolean estaDevuelto) {
        this.estaDevuelto = estaDevuelto;
    }

    public Libro getLibroPrestado() {
        return libroPrestado;
    }

    public void setLibroPrestado(Libro libroPrestado) {
        this.libroPrestado = libroPrestado;
    }

    @Override
    public boolean equals(Object obj){
        boolean exit = false;

        if(obj != null && obj instanceof Prestamo && this.getLibroPrestado().equals((Libro) ((Prestamo) obj).libroPrestado)){
            exit = true;
        }
        return exit;
    }
}
