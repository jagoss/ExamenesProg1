package prog1.entidades;

import java.util.ArrayList;

public final class AudioLibro extends Libro {

    private int duracion;

    public AudioLibro(long isbn, String titulo, ArrayList<String> autores, int duracion){
        super(isbn, titulo, autores);
        this.duracion = duracion;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
}
