package prog1.exceptions;

public class LibroNoPuedePrestarse extends Exception {
}
