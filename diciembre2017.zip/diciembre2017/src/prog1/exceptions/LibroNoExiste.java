package prog1.exceptions;

public class LibroNoExiste extends Exception {
}
