package prog1.exceptions;

public class LibroYaExiste extends Exception {
}
