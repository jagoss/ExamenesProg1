package prog1.exceptions;

public class InformacionIncorrecta extends Exception {
}
