package prog1;

import prog1.entidades.AudioLibro;
import prog1.entidades.Braille;
import prog1.entidades.Libro;
import prog1.entidades.Prestamo;
import prog1.exceptions.InformacionIncorrecta;
import prog1.exceptions.LibroNoExiste;
import prog1.exceptions.LibroNoPuedePrestarse;
import prog1.exceptions.LibroYaExiste;

import java.time.LocalDate;
import java.util.ArrayList;

public class Biblioteca {

    private ArrayList<Libro> listaLibros = new ArrayList<Libro>();
    private ArrayList<Prestamo> listaPrestamos = new ArrayList<Prestamo>();

    public void agregarLibro(long isbn, String titulo, ArrayList<String> autores, boolean esAudioLibro,
                             int duracion, boolean esBraille) throws LibroYaExiste, InformacionIncorrecta {

        if (isbn == 0 || titulo == null || autores == null || "".equals(titulo) || autores.isEmpty()) {
            throw new InformacionIncorrecta();
        }

        Libro nuevoLibro;

        if (esAudioLibro) {
            if (duracion <= 0) {
                throw new InformacionIncorrecta();
            }
            nuevoLibro = new AudioLibro(isbn, titulo, autores, duracion);

        } else if (esBraille) {
            nuevoLibro = new Braille(isbn, titulo, autores);

        } else {
            nuevoLibro = new Libro(isbn, titulo, autores);
        }
        boolean libroExiste = false;

        for (int i = 0; i < listaLibros.size(); i++) {

            if (nuevoLibro.equals(listaLibros.get(i))) {
                libroExiste = true;
                i = listaLibros.size();
            }
        }
        if (libroExiste) {
            throw new LibroYaExiste();
        } else {
            listaLibros.add(nuevoLibro);
            System.out.println("Se ha agregado: " + nuevoLibro.getTitulo());
        }
    }

    public void solicitarPrestamo(long isbn, String cedula, LocalDate fechaDesde, LocalDate fechaHasta)
            throws LibroNoExiste, LibroNoPuedePrestarse, InformacionIncorrecta {

        if (isbn == 0 || cedula == null || fechaDesde == null || fechaHasta == null || "".equals(cedula)) {
            throw new InformacionIncorrecta();
        }
        boolean existeLibro = false;
        Libro libroPrestamo = new Libro(isbn,null,null);

        for(int i=0; i< listaLibros.size() ;i++){

            if(listaLibros.get(i).getIsbn() == isbn){
                existeLibro = true;
                libroPrestamo = listaLibros.get(i);
            }
        }
        if(!existeLibro){
            throw new InformacionIncorrecta();
        }
        if(validarCantidadLibros(cedula) || validarLibrosNoDevueltos(cedula) || validarDisponibilidadLibro(isbn)||
            validarLibroYaFuePrestadoAUsuario(cedula,isbn)){

            throw new LibroNoPuedePrestarse();

        }else{

            Prestamo nuevoPrestamo = new Prestamo(cedula,fechaDesde, fechaHasta,false, libroPrestamo);
           listaPrestamos.add(nuevoPrestamo);
        }
    }

    public void devolverPrestamo(long isbn, String cedula) throws InformacionIncorrecta {

        if (isbn == 0 || cedula == null || " ".equals(cedula)) {
            throw new InformacionIncorrecta();
        }
        Libro libroTemp = new Libro(isbn, null, null);

        for (int i = 0; i < listaLibros.size(); i++) {

            if (listaLibros.get(i).equals(libroTemp)) {
                libroTemp = listaLibros.get(i);
            }
        }
        Prestamo prestamoTemp = new Prestamo(cedula, null, null, true, libroTemp);

        for (int i = 0; i < listaPrestamos.size(); i++) {

            if (listaPrestamos.get(i).equals(prestamoTemp)) {
                listaPrestamos.get(i).setEstaDevuelto(true);
                System.out.println("Ha devuelto el libro " + listaPrestamos.get(i).getLibroPrestado().getTitulo() + "exitosamente!");
            }
        }
    }

    public int obtenerCantidadLibrosBraille() {
        int nExit = 0;

        for (int i = 0; i < listaLibros.size(); i++) {

            if (listaLibros.get(i) instanceof Braille) {
                nExit++;
            }
        }

        return nExit;
    }

    public ArrayList<String> obtenerListasMorosos() {
        ArrayList<String> listaMorosos = new ArrayList<String>();

        Prestamo prestamoTemp;

        for (int i = 0; i < listaPrestamos.size(); i++) {
            prestamoTemp = listaPrestamos.get(i);

            if (prestamoTemp.getHasta().isBefore(LocalDate.now())) {
                listaMorosos.add(prestamoTemp.getCedula());
            }
        }
        return listaMorosos;
    }


    private boolean validarCantidadLibros(String cedula) {
        boolean bExit = false;

        Prestamo prestamoTemp;
        int counter =0;

        for (int i = 0; i < listaPrestamos.size(); i++) {

            prestamoTemp = listaPrestamos.get(i);

            if (prestamoTemp.getCedula().equals(cedula) && !prestamoTemp.isEstaDevuelto()) {
                counter++;
            }
        }

        if (counter >= 3){
            bExit = true;
        }

        return bExit;
    }

    private boolean validarLibrosNoDevueltos(String cedula) {
        boolean bExit = false;

        Prestamo prestamoTemp;

        for (int i = 0; i < listaPrestamos.size(); i++) {

            prestamoTemp = listaPrestamos.get(i);

            if (prestamoTemp.getCedula().equals(cedula) && !prestamoTemp.isEstaDevuelto() &&
                    prestamoTemp.getHasta().isBefore(LocalDate.now())) {
                bExit = true;
            }
        }

        return bExit;
    }

    private boolean validarDisponibilidadLibro(long isbn) {
        boolean bExit = false;

        Prestamo prestamoTemp;

        for (int i = 0; i < listaPrestamos.size(); i++) {

            prestamoTemp = listaPrestamos.get(i);

            if (prestamoTemp.getLibroPrestado().getIsbn() == isbn && !prestamoTemp.isEstaDevuelto()) {
                bExit = true;
            }
        }
        return bExit;
    }

    private boolean validarLibroYaFuePrestadoAUsuario(String cedula, long isbn) {
        boolean bExit = false;

        Libro libroTemp = new Libro(isbn, null, null);

        for (int i = 0; i < listaLibros.size(); i++) {

            if (listaLibros.get(i).equals(libroTemp)) {
                libroTemp = listaLibros.get(i);
            }
        }
        Prestamo prestamoTemp = new Prestamo(cedula, null, null, false, libroTemp);
        Prestamo prestamoFor;

        for (int i = 0; i < listaPrestamos.size(); i++) {

            prestamoFor = listaPrestamos.get(i);

            if (prestamoFor.equals(prestamoTemp) && !prestamoFor.isEstaDevuelto()) {
                bExit = true;

            }else if (prestamoFor.equals(prestamoTemp) && prestamoFor.isEstaDevuelto()){

                if (LocalDate.now().minusDays(30).compareTo(prestamoFor.getHasta()) > 0){
                    bExit = true;
                }
            }
        }
        return bExit;
    }
}