package prog1;

import prog1.exceptions.InformacionIncorrecta;
import prog1.exceptions.LibroNoExiste;
import prog1.exceptions.LibroNoPuedePrestarse;
import prog1.exceptions.LibroYaExiste;

import java.time.LocalDate;
import java.util.ArrayList;

public class Principal {

    public static void main(String[] args){

        Biblioteca miBiblioteca = new Biblioteca();

        ArrayList<String> autores = new ArrayList<>();
        autores.add("alguien famoso");
        LocalDate fechaHasta = LocalDate.of(2019,1,10);

        try {

            miBiblioteca.agregarLibro(123,"Quijote",autores,false,0,false);
            autores.clear();
            autores.add("J.K. Rowlling");
            miBiblioteca.agregarLibro(1,"Harry Potter 1", autores, false, 0, false );
            miBiblioteca.agregarLibro(12,"Harry Potter 1", autores, false, 0, true );
            miBiblioteca.agregarLibro(13,"Harry Potter 2", autores, true, 300, false );
            System.out.println("Cantidad de libros en braille: "+ miBiblioteca.obtenerCantidadLibrosBraille());

            miBiblioteca.solicitarPrestamo(123, "111254", LocalDate.now(), fechaHasta);
            miBiblioteca.solicitarPrestamo(12, "111254", LocalDate.now(), fechaHasta);
            miBiblioteca.solicitarPrestamo(13, "111254", LocalDate.now(), fechaHasta);
            //aca tiene que tirar una exception
            //miBiblioteca.solicitarPrestamo(1, "111254", LocalDate.now(), fechaHasta);

            miBiblioteca.agregarLibro(14,"Harry Potter 3", autores, false, 0, false );
            miBiblioteca.agregarLibro(15,"Harry Potter 3", autores, false, 0, false );

            miBiblioteca.devolverPrestamo(12,"111254");
            miBiblioteca.solicitarPrestamo(12, "11254", LocalDate.now(), fechaHasta);
            miBiblioteca.devolverPrestamo(12,"11254");
            miBiblioteca.solicitarPrestamo(14, "11254", LocalDate.now(), fechaHasta);
            //aca tiene que tirar una exception
            miBiblioteca.solicitarPrestamo(123, "111254", LocalDate.now(), fechaHasta);



        } catch (LibroYaExiste libroYaExiste) {
            libroYaExiste.printStackTrace();
        } catch (InformacionIncorrecta informacionIncorrecta) {
            informacionIncorrecta.printStackTrace();
        } catch (LibroNoPuedePrestarse libroNoPuedePrestarse) {
            libroNoPuedePrestarse.printStackTrace();
        } catch (LibroNoExiste libroNoExiste) {
            libroNoExiste.printStackTrace();
        }
    }
}

