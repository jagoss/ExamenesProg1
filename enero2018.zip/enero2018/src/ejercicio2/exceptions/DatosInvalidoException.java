package ejercicio2.exceptions;

public class DatosInvalidoException extends Exception {

    public DatosInvalidoException(String dato_invalido) {
        super(dato_invalido);
    }
}
