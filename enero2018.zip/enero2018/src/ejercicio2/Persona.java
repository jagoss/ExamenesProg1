package ejercicio2;

import ejercicio2.exceptions.DatosInvalidoException;

public class Persona {

    private String name;
    private float weight;
    private int[][] calendar = new int[12][30];

    public Persona(String name, float weight){

        this.name = name;
        this.weight = weight;
    }

    public void ingresarPasosDelDia(int nDia, int nMes, int nPasos) throws DatosInvalidoException {
        if (checkEntrada(nDia,0) || checkEntrada(nMes,1) || checkEntrada(nPasos,2) ){

            calendar[nMes-1][nDia-1] = calendar[nMes-1][nDia-1] + nPasos;

            System.out.println();
            System.out.println("Datos actualizados correctamente!");
            System.out.println(name + ", ha caminando " + nPasos + " pasos el " + nDia + "/"+ nMes + "/2018");
            System.out.println();
        }

    }

    public int obtenerPromedioDePasos(int nMes) throws DatosInvalidoException {
        int nExit = 0;

        if (checkEntrada(nMes, 1)){
            nExit = cantidadTotalDePasos(nMes)/30;
        }

        return nExit;
    }

    public int obtenerPasosFaltantes(int nMes) throws DatosInvalidoException {

        int promedioDePasos = obtenerPromedioDePasos(nMes);
        int nExit = 0;

        if (promedioDePasos >= 10000){

            nExit = 0;

        }else{
            nExit = 10000*30 - cantidadTotalDePasos(nMes);
        }

        return nExit;
    }


        //Operaciones Auxiliares
    private boolean checkEntrada(int nEntrada, int nTipoDato) throws DatosInvalidoException {

        boolean nExit = true;

        switch (nTipoDato){
            case 0:
                if (nEntrada <= 0 || nEntrada > 30) {
                    throw new DatosInvalidoException("Dia invalido");
                }
                break;

            case 1:
                if (nEntrada <=0 || nEntrada > 12) {
                    throw new DatosInvalidoException("Mes Invalido");
                }
                break;

            case 2:
                if (nEntrada < 0) {
                    throw new DatosInvalidoException("Cantidad de pasos Invalida");
                }
                break;
        }

        return nExit;
    }

    private int cantidadTotalDePasos(int nMes){
        int nPasosTotales =0;

        for (int nDia = 0; nDia<30; nDia++){
            nPasosTotales = nPasosTotales + calendar[nMes-1][nDia];
        }
        return nPasosTotales;
    }
}
