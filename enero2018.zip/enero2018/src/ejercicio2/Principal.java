package ejercicio2;

import ejercicio2.exceptions.DatosInvalidoException;

public class Principal {

    public static void main(String[] args){

        Persona persona1 = new Persona("Juan", (float) 64.5);

        try {
            persona1.ingresarPasosDelDia(1,12,5000);
            System.out.println("Pasos faltantes en diciembre: " + persona1.obtenerPasosFaltantes(12));

            persona1.ingresarPasosDelDia(1,12,5000);
            System.out.println("Pasos faltantes en diciembre: " + persona1.obtenerPasosFaltantes(12));

            for (int i = 1; i<31; i++) {
                persona1.ingresarPasosDelDia(i, 10, 10050);

                System.out.println("Promedio de pasos por dia en octubre: " + persona1.obtenerPromedioDePasos(10));

                System.out.println("Pasos faltantes en octubre: " + persona1.obtenerPasosFaltantes(10));
            }


        } catch (DatosInvalidoException e) {
            e.printStackTrace();
        }
    }
}
