package prog1.excepciones;

public class InformacionIngredienteInvalida extends Exception {

    public InformacionIngredienteInvalida(String mensaje){
        super(mensaje);
    }
}
