package prog1.excepciones;

public class ParamentroInvalido extends Exception {
}
