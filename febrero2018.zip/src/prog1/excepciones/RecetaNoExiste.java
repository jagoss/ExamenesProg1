package prog1.excepciones;

public class RecetaNoExiste extends Exception {

    public RecetaNoExiste(String mensaje){
        super(mensaje);
    }
}
