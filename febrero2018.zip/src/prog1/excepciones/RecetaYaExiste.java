package prog1.excepciones;

public class RecetaYaExiste extends Exception {
    public RecetaYaExiste(String mensaje){
        super(mensaje);
    }
}
