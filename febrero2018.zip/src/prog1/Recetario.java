package prog1;

import prog1.entidades.Ingrediente;
import prog1.entidades.Receta;
import prog1.excepciones.InformacionIngredienteInvalida;
import prog1.excepciones.ParamentroInvalido;
import prog1.excepciones.RecetaNoExiste;
import prog1.excepciones.RecetaYaExiste;

public class Recetario {

    private Receta[] listaRecetas = new Receta[20];

    //Metodo mas sencillo de todos. Conveniente arrancar por aca.
    public void crearReceta(String sNombreReceta, int nCalorias) throws RecetaYaExiste, ParamentroInvalido {

        if(sNombreReceta==null || sNombreReceta.equals("") || nCalorias <= 0){
            throw new ParamentroInvalido();
        }
        for(int i = 0; i < listaRecetas.length; i++){
            if (listaRecetas[i] != null && listaRecetas[i].getNombre().equals(sNombreReceta)) {

                throw new RecetaYaExiste("Receta ya existe en el recetario");

            }else if(listaRecetas[i] == null){
                Receta nuevaReceta = new Receta(sNombreReceta, nCalorias);
                listaRecetas[i] = nuevaReceta;
                i = listaRecetas.length;
            }
        }
    }

    public void agregarIngredienteReceta(String sNombreReceta, String sIngrediente, int nCantidad)
            throws RecetaNoExiste, InformacionIngredienteInvalida {

        if(sNombreReceta == null || "".equals(sNombreReceta) || nCantidad <= 0){
           throw new InformacionIngredienteInvalida("parametros invalidos");
        }

        boolean existe = false;

        for(int counter = 0; counter < listaRecetas.length; counter++){

            Receta temporal = listaRecetas[counter];

            if(temporal!= null && sNombreReceta.equals(temporal.getNombre())){

                existe = true;

                if (temporal.buscarIngrediente(sIngrediente)!= null){
                    temporal.buscarIngrediente(sIngrediente).setCantidad(nCantidad);

                }else{
                    Ingrediente nuevoIngrediente = new Ingrediente(sIngrediente, nCantidad);
                    temporal.agregarIngrediente(nuevoIngrediente);
                }
                counter = listaRecetas.length;
            }
        }
        if(!existe){ throw new RecetaNoExiste("Receta no  existe en el recetario");}
    }

    public String[] buscarRecetas(String[] vecIngredientes, int nCalorias) throws ParamentroInvalido {

        String[] recetasValidas = new String[listaRecetas.length];
        int size = 0;
        String[] listaFinal = null;

        if(vecIngredientes == null || nCalorias <= 0){
            throw new ParamentroInvalido();
        }

        for(int i = 0; i < listaRecetas.length; i++){

            Receta temporal = listaRecetas[i];

            if(temporal != null && temporal.getCalorias() == nCalorias && temporal.checkIngredientes(vecIngredientes)){
                recetasValidas[size] = temporal.getNombre();
                size++;

            }else if (temporal == null){
                i = listaRecetas.length;
            }
        }
        //Uso listaFinal para que el array no tenga lugares vacios
        if (size != 0){
            listaFinal = new String[size];

            for (int i = 0; i < size; i++){

                if (recetasValidas[i] != null){
                    listaFinal[i] = recetasValidas[i];
                }
            }
        }else {
            listaFinal = new String[] {"No hay recetas"};
        }

        return listaFinal;
    }

    //Metodo sencillo de realizar. Solamente revisar en un array si hay cierto String. Igualmente hay que tener cuidado
    public void imprimirReceta(String sNombreReceta) throws RecetaNoExiste, ParamentroInvalido {

        if (sNombreReceta!= null && !sNombreReceta.equals("")){
            boolean existe = false;

            for(int counter=0; counter< listaRecetas.length; counter++){

                if ( listaRecetas[counter]!= null && sNombreReceta.equals(listaRecetas[counter].getNombre())){
                    existe = true;
                    Receta recetaBuscada = listaRecetas[counter];

                    System.out.println("Nombre: "+ recetaBuscada.getNombre());
                    System.out.println("Calorias: " + recetaBuscada.getCalorias());
                    System.out.println("Ingredientes:");
                    Ingrediente[] ingredientes = recetaBuscada.getListaIngredientes();
                    for(int i=0; i< ingredientes.length; i++){
                        if (ingredientes[i]!=null) {
                            System.out.println("    " + ingredientes[i].getNombre());
                        }else{
                            i = ingredientes.length;
                        }
                    }
                }else if (listaRecetas[counter] == null){
                    counter = listaRecetas.length;
                }
            }
            if (!existe){
                throw new RecetaNoExiste("receta no existe");}
        }else{
            throw new ParamentroInvalido();
        }
    }
}
