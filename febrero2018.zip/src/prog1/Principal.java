package prog1;

import prog1.entidades.Ingrediente;
import prog1.excepciones.InformacionIngredienteInvalida;
import prog1.excepciones.ParamentroInvalido;
import prog1.excepciones.RecetaNoExiste;
import prog1.excepciones.RecetaYaExiste;

public class Principal {

    public static void main(String[] args){
        Recetario miRecetario = new Recetario();

        try {

            miRecetario.crearReceta("omelete", 110);
            miRecetario.agregarIngredienteReceta("omelete", "jamon", 1);
            miRecetario.agregarIngredienteReceta("omelete", "huevo", 3);
            miRecetario.agregarIngredienteReceta("omelete", "queso", 2);

            miRecetario.crearReceta("Huevo duro",50);
            miRecetario.agregarIngredienteReceta("Huevo duro", "huevo", 1);

            String[] ingredientes = {"huevo"};

            String[] resultado1 = miRecetario.buscarRecetas(ingredientes, 50);
            String[] resultado2 = miRecetario.buscarRecetas(ingredientes, 110);

            for (int i =0; i < resultado1.length; i++){
                System.out.println(resultado1[i]);
            }

            System.out.println();

            for (int i =0; i < resultado2.length; i++){
                System.out.println(resultado2[i]);
            }
            System.out.println();

            ingredientes = new String[]{"huevo", "jamon", "queso"};
            miRecetario.buscarRecetas(ingredientes, 110);

            miRecetario.imprimirReceta("omelete");
            System.out.println();
            miRecetario.imprimirReceta("Huevo duro");


        } catch (RecetaYaExiste recetaYaExiste) {
            recetaYaExiste.printStackTrace();
        } catch (ParamentroInvalido paramentroInvalido) {
            paramentroInvalido.printStackTrace();
        } catch (RecetaNoExiste recetaNoExiste) {
            recetaNoExiste.printStackTrace();
        } catch (InformacionIngredienteInvalida informacionIngredienteInvalida) {
            informacionIngredienteInvalida.printStackTrace();
        }

    }
}
