package prog1.entidades;

import prog1.excepciones.InformacionIngredienteInvalida;

public class Receta {

    private String nombre;
    private Ingrediente[] listaIngredientes = new Ingrediente[10];
    private int calorias;

    public Receta(String nombre, int calorias){

        this.nombre = nombre;
        this.calorias = calorias;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Ingrediente[] getListaIngredientes() {
        return listaIngredientes;
    }

    public void setListaIngredientes(Ingrediente[] listaIngredientes) {
        this.listaIngredientes = listaIngredientes;
    }

    public int getCalorias() {
        return calorias;
    }

    public void setCalorias(int calorias) {
        this.calorias = calorias;
    }

    public Ingrediente buscarIngrediente(String sIngrediente){
        Ingrediente ingredienteBuscado = null;

        for (int i = 0; i< listaIngredientes.length; i++){
            if ( listaIngredientes[i] !=null && sIngrediente.equals(listaIngredientes[i].getNombre())){
                ingredienteBuscado = listaIngredientes[i];

            }else if (listaIngredientes[i] == null){
                i = listaIngredientes.length;
            }
        }
        return ingredienteBuscado;
    }

    public void agregarIngrediente(Ingrediente ingrediente){

        int counter = 0;

        while(counter < listaIngredientes.length && listaIngredientes[counter]!=null){
            counter++;
        }
        if (counter < listaIngredientes.length && listaIngredientes[counter]== null) {
            listaIngredientes[counter] = ingrediente;
        }else{
            System.out.println("No hay mas lugar para ingredientes");
        }
    }

    public boolean checkIngredientes(String[] ingredientes){

        boolean estanTodos = true;
        int counter = 0;

        for (int i = 0; i < listaIngredientes.length; i++) {
            if (listaIngredientes[i]!=null && i < ingredientes.length){

                for (int j = 0; j < ingredientes.length; j++) {

                    if (ingredientes[j] != null && ingredientes[i].equals(listaIngredientes[i].getNombre())) {
                        counter++;
                    }
                }
            }else{ i = listaIngredientes.length;}
        }
        if (counter != ingredientes.length){ estanTodos = false; }

        return estanTodos;
    }
}
